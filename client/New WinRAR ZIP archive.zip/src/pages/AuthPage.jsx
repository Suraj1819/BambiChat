import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { api } from '@/lib/api';
import { setSession } from '@/lib/session';

/**
 * Register or sign in with username.
 * Production path will use Supabase phone OTP; this is the real session boundary.
 */
export function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState('login'); // login | register
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    const u = username.trim().toLowerCase();
    if (!u) {
      setError('Enter a username');
      return;
    }
    setLoading(true);
    try {
      const res =
        mode === 'register'
          ? await api.register(u, displayName.trim() || u)
          : await api.login(u);
      setSession({ token: res.data.token, user: res.data.user });
      navigate('/', { replace: true });
    } catch (err) {
      setError(err.message || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-full items-center justify-center bg-bambi-background p-4">
      <div className="w-full max-w-md animate-fade-in">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-bambi-xl bg-bambi-primary text-2xl font-bold text-white shadow-bambi-lg">
            B
          </div>
          <h1 className="text-heading-1 text-bambi-text">Bambi</h1>
          <p className="mt-1 text-body text-bambi-text-secondary">
            Private messaging with end-to-end encryption
          </p>
        </div>

        <div className="rounded-bambi-xl border border-bambi-border bg-bambi-surface p-6 shadow-bambi">
          <div className="mb-4 flex rounded-bambi bg-bambi-background p-1">
            <button
              type="button"
              className={`flex-1 rounded-bambi py-2 text-label transition-colors ${
                mode === 'login'
                  ? 'bg-bambi-surface text-bambi-primary shadow-bambi-sm'
                  : 'text-bambi-text-secondary'
              }`}
              onClick={() => setMode('login')}
            >
              Sign in
            </button>
            <button
              type="button"
              className={`flex-1 rounded-bambi py-2 text-label transition-colors ${
                mode === 'register'
                  ? 'bg-bambi-surface text-bambi-primary shadow-bambi-sm'
                  : 'text-bambi-text-secondary'
              }`}
              onClick={() => setMode('register')}
            >
              Create account
            </button>
          </div>

          <form onSubmit={submit} className="space-y-4">
            <div>
              <label htmlFor="username" className="mb-1.5 block text-label text-bambi-text">
                Username
              </label>
              <Input
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="yourname"
                autoComplete="username"
                autoFocus
              />
              <p className="mt-1.5 text-caption text-bambi-text-secondary">
                3–30 characters, letters, numbers, underscore
              </p>
            </div>

            {mode === 'register' && (
              <div>
                <label htmlFor="displayName" className="mb-1.5 block text-label text-bambi-text">
                  Display name
                </label>
                <Input
                  id="displayName"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="Your name"
                  autoComplete="name"
                />
              </div>
            )}

            {error && (
              <p className="text-body-sm text-bambi-error" role="alert">
                {error}
              </p>
            )}

            <Button type="submit" variant="primary" className="w-full" disabled={loading}>
              {loading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <>
                  {mode === 'register' ? 'Create account' : 'Sign in'}
                  <ArrowRight className="h-4 w-4" />
                </>
              )}
            </Button>
          </form>
        </div>

        <p className="mt-6 text-center text-caption text-bambi-text-secondary">
          Messages are end-to-end encrypted. The server cannot read your private messages.
        </p>
      </div>
    </div>
  );
}
