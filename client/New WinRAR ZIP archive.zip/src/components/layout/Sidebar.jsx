import { Search, MessageSquarePlus, Settings, Users } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Avatar } from '@/components/ui/Avatar';

/**
 * Conversation list sidebar with search, new chat, and profile entry.
 */
export function Sidebar({
  currentUser,
  searchQuery = '',
  onSearchChange,
  onNewChat,
  onNewGroup,
  onOpenSettings,
  onOpenFriends,
  children,
  className,
}) {
  return (
    <div className={cn('flex h-full flex-col', className)}>
      <header className="flex items-center justify-between gap-2 border-b border-bambi-border px-4 py-3">
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-bambi bg-bambi-primary text-white font-bold text-sm">
            B
          </div>
          <span className="text-heading-3 text-bambi-text tracking-tight">
            Bambi
          </span>
        </div>
        <div className="flex items-center gap-0.5">
          <Button
            variant="icon"
            onClick={onNewChat}
            aria-label="New conversation"
            title="New conversation"
          >
            <MessageSquarePlus className="h-5 w-5" />
          </Button>
          {onNewGroup && (
            <Button
              variant="icon"
              onClick={onNewGroup}
              aria-label="New group"
              title="New group"
            >
              <Users className="h-5 w-5" />
            </Button>
          )}
          <Button
            variant="icon"
            onClick={onOpenSettings}
            aria-label="Sign out"
            title="Sign out"
          >
            <Settings className="h-5 w-5" />
          </Button>
        </div>
      </header>

      <div className="px-3 py-2.5">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-bambi-text-secondary" />
          <Input
            type="search"
            placeholder="Search conversations"
            value={searchQuery}
            onChange={(e) => onSearchChange?.(e.target.value)}
            className="pl-9 py-2 text-body-sm"
            aria-label="Search conversations"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto overscroll-contain">
        {children}
      </div>

      {currentUser && (
        <footer className="flex items-center gap-3 border-t border-bambi-border px-4 py-3">
          <Avatar
            src={currentUser.avatarUrl}
            name={currentUser.displayName || currentUser.username}
            size="sm"
            online
          />
          <div className="min-w-0 flex-1">
            <p className="truncate text-label text-bambi-text">
              {currentUser.displayName || currentUser.username}
            </p>
            <p className="truncate text-caption text-bambi-text-secondary">
              @{currentUser.username}
            </p>
          </div>
          <Button
            variant="icon"
            aria-label="Friends"
            title="Friends"
            onClick={onOpenFriends}
          >
            <Users className="h-5 w-5" />
          </Button>
        </footer>
      )}
    </div>
  );
}
