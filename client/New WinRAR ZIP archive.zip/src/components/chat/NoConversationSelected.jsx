import { MessageSquare } from 'lucide-react';
import { EmptyState } from '@/components/ui/EmptyState';

export function NoConversationSelected() {
  return (
    <div className="flex h-full flex-1 items-center justify-center bg-bambi-background">
      <EmptyState
        icon={MessageSquare}
        title="Select a conversation"
        description="Choose a chat from the sidebar or start a new one to begin messaging."
      />
    </div>
  );
}
