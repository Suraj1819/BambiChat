import { useEffect, useRef } from 'react';
import { cn } from '@/lib/utils';
import { MessageBubble } from './MessageBubble';
import { EmptyState } from '@/components/ui/EmptyState';
import { MessageSquare } from 'lucide-react';

export function MessageTimeline({
  messages = [],
  currentUserId,
  isLoading = false,
  onDownloadAttachment,
  className,
}) {
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length]);

  if (isLoading) {
    return (
      <div className={cn('flex flex-1 items-center justify-center', className)}>
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-bambi-primary border-t-transparent" />
      </div>
    );
  }

  if (messages.length === 0) {
    return (
      <div className={cn('flex flex-1 items-center justify-center', className)}>
        <EmptyState
          icon={MessageSquare}
          title="No messages yet"
          description="Send a message or attach an encrypted file."
        />
      </div>
    );
  }

  return (
    <div
      className={cn(
        'flex flex-1 flex-col gap-2 overflow-y-auto overscroll-contain px-3 py-4 md:px-6',
        className
      )}
    >
      {messages.map((msg) => (
        <MessageBubble
          key={msg.id || msg.clientMessageId}
          message={msg}
          isOwn={msg.senderId === currentUserId}
          onDownloadAttachment={onDownloadAttachment}
        />
      ))}
      <div ref={bottomRef} />
    </div>
  );
}
