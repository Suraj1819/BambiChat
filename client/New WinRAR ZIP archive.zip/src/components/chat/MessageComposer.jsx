import { useState, useRef } from 'react';
import { Paperclip, Send, Smile, Mic, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/Button';

/**
 * Message composer with optional encrypted file attach.
 */
export function MessageComposer({
  onSend,
  onAttach,
  disabled = false,
  uploading = false,
  uploadProgress = 0,
  placeholder = 'Type a message',
  onTypingChange,
  className,
}) {
  const [text, setText] = useState('');
  const textareaRef = useRef(null);
  const fileRef = useRef(null);
  const typingTimer = useRef(null);

  const handleSend = () => {
    const value = text.trim();
    if (!value || disabled || uploading) return;
    onSend?.(value);
    setText('');
    onTypingChange?.(false);
    textareaRef.current?.focus();
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className={cn('border-t border-bambi-border bg-bambi-surface px-3 py-2.5 md:px-4', className)}>
      {uploading && (
        <div className="mb-2">
          <div className="mb-1 flex items-center justify-between text-caption text-bambi-text-secondary">
            <span>Encrypting & uploading…</span>
            <span>{Math.round(uploadProgress)}%</span>
          </div>
          <div className="h-1.5 overflow-hidden rounded-full bg-bambi-border">
            <div
              className="h-full rounded-full bg-bambi-primary transition-all"
              style={{ width: `${uploadProgress}%` }}
            />
          </div>
        </div>
      )}

      <div className="flex items-end gap-1.5">
        <input
          ref={fileRef}
          type="file"
          className="hidden"
          accept="image/*,.pdf,.txt,.doc,.docx,.xls,.xlsx,video/mp4,video/webm"
          onChange={(e) => {
            const f = e.target.files?.[0];
            e.target.value = '';
            if (f) onAttach?.(f);
          }}
        />
        <Button
          variant="icon"
          disabled={disabled || uploading}
          aria-label="Attach file"
          title="Attach encrypted file"
          className="shrink-0"
          onClick={() => fileRef.current?.click()}
        >
          {uploading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Paperclip className="h-5 w-5" />}
        </Button>

        <div className="relative min-w-0 flex-1">
          <textarea
            ref={textareaRef}
            value={text}
            onChange={(e) => {
              const v = e.target.value;
              setText(v);
              if (onTypingChange) {
                onTypingChange(true);
                clearTimeout(typingTimer.current);
                typingTimer.current = setTimeout(() => onTypingChange(false), 1500);
              }
            }}
            onKeyDown={handleKeyDown}
            placeholder={placeholder}
            disabled={disabled || uploading}
            rows={1}
            className={cn('bambi-input max-h-32 min-h-[42px] resize-none py-2.5 pr-10 text-body')}
            aria-label="Message input"
          />
          <Button
            variant="icon"
            disabled={disabled}
            aria-label="Emoji"
            className="absolute bottom-1 right-1"
          >
            <Smile className="h-5 w-5" />
          </Button>
        </div>

        {text.trim() ? (
          <Button
            variant="primary"
            onClick={handleSend}
            disabled={disabled || uploading}
            aria-label="Send message"
            className="h-[42px] shrink-0 rounded-bambi px-3"
          >
            <Send className="h-5 w-5" />
          </Button>
        ) : (
          <Button variant="icon" disabled className="shrink-0" aria-label="Voice (soon)">
            <Mic className="h-5 w-5" />
          </Button>
        )}
      </div>
    </div>
  );
}
